import Vue from "vue";
import App from "./App.vue";
import JSPDF from "jspdf";
import "jspdf-autotable";
Vue.use(JSPDF);
Vue.config.productionTip = false;

new Vue({
  render: h => h(App)
}).$mount("#app");
