<template>
  <div id="app">
    <button @click="generalPDF">Export to PDF</button>
  </div>
</template>

<script>
import HelloWorld from "./components/HelloWorld";
import jspdf from "jspdf";
export default {
  name: "App",
  data() {
    return {};
  },
  components: {
    HelloWorld
  },
  methods: {
    generalPDF() {
      const doc = new jspdf();
      doc.autoTable({
        showHead:"firstPage",
   
        columnStyles: { europe: { halign: "center" } },
        body: [{"No":1,"Name":"Sayher","Email":"sayherlove@gmail.com","Date_input":"2019-11-12T04:10:55.000Z"},{"No":2,"Name":"Test","Email":"Test@gmail.com","Date_input":"2019-11-12T04:10:55.000Z"},{"No":3,"Name":"xiaosai","Email":"xiaosai53@gmail.com","Date_input":"2019-11-12T04:10:55.000Z"},{"No":4,"Name":"Long","Email":"long@yahoo.com","Date_input":"2019-11-12T04:10:55.000Z"},{"No":5,"Name":"Sayher","Email":"sayherlove@gmail.com","Date_input":"2019-11-12T04:11:01.000Z"},{"No":6,"Name":"Test","Email":"Test@gmail.com","Date_input":"2019-11-12T04:11:01.000Z"},{"No":7,"Name":"xiaosai","Email":"xiaosai53@gmail.com","Date_input":"2019-11-12T04:11:01.000Z"},{"No":8,"Name":"Long","Email":"long@yahoo.com","Date_input":"2019-11-12T04:11:02.000Z"},{"No":9,"Name":"Sayher","Email":"sayherlove@gmail.com","Date_input":"2019-11-12T04:11:19.000Z"},{"No":10,"Name":"Test","Email":"Test@gmail.com","Date_input":"2019-11-12T04:11:19.000Z"},{"No":11,"Name":"xiaosai","Email":"xiaosai53@gmail.com","Date_input":"2019-11-12T04:11:19.000Z"},{"No":12,"Name":"Long","Email":"long@yahoo.com","Date_input":"2019-11-12T04:11:19.000Z"},{"No":13,"Name":"Sayher","Email":"sayherlove@gmail.com","Date_input":"2019-11-13T01:25:13.000Z"},{"No":14,"Name":"Test","Email":"Test@gmail.com","Date_input":"2019-11-13T01:25:13.000Z"},{"No":15,"Name":"xiaosai","Email":"xiaosai53@gmail.com","Date_input":"2019-11-13T01:25:13.000Z"},{"No":16,"Name":"Long","Email":"long@yahoo.com","Date_input":"2019-11-13T01:25:13.000Z"},{"No":17,"Name":"Sayher","Email":"sayherlove@gmail.com","Date_input":"2019-11-13T01:47:24.000Z"},{"No":18,"Name":"Test","Email":"Test@gmail.com","Date_input":"2019-11-13T01:47:24.000Z"},{"No":19,"Name":"xiaosai","Email":"xiaosai53@gmail.com","Date_input":"2019-11-13T01:47:24.000Z"},{"No":20,"Name":"Long","Email":"long@yahoo.com","Date_input":"2019-11-13T01:47:24.000Z"},{"No":21,"Name":"Sayher","Email":"sayherlove@gmail.com","Date_input":"2019-11-13T01:48:10.000Z"},{"No":22,"Name":"Test","Email":"Test@gmail.com","Date_input":"2019-11-13T01:48:10.000Z"},{"No":23,"Name":"xiaosai","Email":"xiaosai53@gmail.com","Date_input":"2019-11-13T01:48:10.000Z"},{"No":24,"Name":"Long","Email":"long@yahoo.com","Date_input":"2019-11-13T01:48:10.000Z"},{"No":25,"Name":"Sayher","Email":"sayherlove@gmail.com","Date_input":"2019-11-13T06:29:46.000Z"},{"No":26,"Name":"Test","Email":"Test@gmail.com","Date_input":"2019-11-13T06:29:46.000Z"},{"No":27,"Name":"xiaosai","Email":"xiaosai53@gmail.com","Date_input":"2019-11-13T06:29:46.000Z"},{"No":28,"Name":"Long","Email":"long@yahoo.com","Date_input":"2019-11-13T06:29:46.000Z"},{"No":29,"Name":"Sayher","Email":"sayherlove@gmail.com","Date_input":"2019-11-13T07:13:32.000Z"},{"No":30,"Name":"Test","Email":"Test@gmail.com","Date_input":"2019-11-13T07:13:32.000Z"},{"No":31,"Name":"xiaosai","Email":"xiaosai53@gmail.com","Date_input":"2019-11-13T07:13:32.000Z"},{"No":32,"Name":"Long","Email":"long@yahoo.com","Date_input":"2019-11-13T07:13:33.000Z"},{"No":33,"Name":"Sayher","Email":"sayherlove@gmail.com","Date_input":"2019-11-13T07:55:00.000Z"},{"No":34,"Name":"Test","Email":"Test@gmail.com","Date_input":"2019-11-13T07:55:00.000Z"},{"No":35,"Name":"xiaosai","Email":"xiaosai53@gmail.com","Date_input":"2019-11-13T07:55:00.000Z"},{"No":36,"Name":"Long","Email":"long@yahoo.com","Date_input":"2019-11-13T07:55:00.000Z"},{"No":37,"Name":"Sayher","Email":"sayherlove@gmail.com","Date_input":"2019-11-13T08:36:39.000Z"},{"No":38,"Name":"Test","Email":"Test@gmail.com","Date_input":"2019-11-13T08:36:40.000Z"},{"No":39,"Name":"xiaosai","Email":"xiaosai53@gmail.com","Date_input":"2019-11-13T08:36:40.000Z"},{"No":40,"Name":"Long","Email":"long@yahoo.com","Date_input":"2019-11-13T08:36:40.000Z"},{"No":41,"Name":"Sayher","Email":"sayherlove@gmail.com","Date_input":"2019-11-15T01:45:16.000Z"},{"No":42,"Name":"Test","Email":"Test@gmail.com","Date_input":"2019-11-15T01:45:16.000Z"},{"No":43,"Name":"xiaosai","Email":"xiaosai53@gmail.com","Date_input":"2019-11-15T01:45:16.000Z"},{"No":44,"Name":"Long","Email":"long@yahoo.com","Date_input":"2019-11-15T01:45:16.000Z"},{"No":45,"Name":"Sayher","Email":"sayherlove@gmail.com","Date_input":"2019-11-18T05:51:41.000Z"},{"No":46,"Name":"Test","Email":"Test@gmail.com","Date_input":"2019-11-18T05:51:41.000Z"},{"No":47,"Name":"xiaosai","Email":"xiaosai53@gmail.com","Date_input":"2019-11-18T05:51:41.000Z"},{"No":48,"Name":"Long","Email":"long@yahoo.com","Date_input":"2019-11-18T05:51:41.000Z"}],
        columns: [
          { header: "No", dataKey: "No" },
          { header: "Name", dataKey: "Name" },
          { header: "Email", dataKey: "Email" },
          { header: "Date", dataKey: "Date_input" },
        ]
      });
      doc.save("test.pdf");
    }
  }
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
